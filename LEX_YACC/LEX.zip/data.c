#include <stdio.h>

//Coment line1 //
/* Testing comment
lines test 1 //
test2
*/

int main()
{
	//Hello world program
	printf("Hello world!\n");
	/*testing 3 //
	make something */
	return 0;
}	
